# Automated Web Vulnerability Scanning Tool

## Installation
```
git clone https://github.com/Chittu13/web_auto_scan.git
cd web_auto_scan
chmod +x *
sudo apt-get installlibcurl4-openssl-dev
./bash.sh
```
### Nmap scan
![img1](/img/img1.png)
### Whatweb scan
![img2](/img/img2.png)
### Endpoint scan
![img3](/img/img3.png)
### vuln scan
![img4](/img/img4.png)
