#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <sstream>
#include <string>
#include <regex>
#include <unistd.h>
#include <fstream>
#include <sys/stat.h>
#include <set>
#include <vector>
#include <curl/curl.h>

using namespace std;

// ANSI color codes
const string GREEN = "\033[32m";
const string YELLOW = "\033[33m";
const string CYAN = "\033[36m";
const string RESET = "\033[0m";
const string BOLD = "\033[1m";

// Create directory if not exists
void createDirectory(const string& dirPath) {
    mkdir("result", 0777);
    mkdir(dirPath.c_str(), 0777);
}

// Extract domain name
string extractDomain(const string& url) {
    string domain = url;
    if (domain.find("http://") == 0) domain = domain.substr(7);
    else if (domain.find("https://") == 0) domain = domain.substr(8);
    if (domain.find("www.") == 0) domain = domain.substr(4);
    size_t pos = domain.find('/');
    if (pos != string::npos) domain = domain.substr(0, pos);
    return domain;
}

// Run Nmap and filter output
void runNmap(const string& domain, const string& outputPath) {
    string command = "nmap -sV --open " + domain + " 2>&1";
    FILE* fp = popen(command.c_str(), "r");
    if (!fp) {
        cerr << YELLOW << "[!] Failed to run nmap command." << RESET << endl;
        return;
    }

    char buffer[128];
    string nmap_output;
    while (fgets(buffer, sizeof(buffer), fp)) nmap_output += buffer;
    fclose(fp);

    ofstream outFile(outputPath);
    outFile << nmap_output;
    outFile.close();

    cout << GREEN << "PORT   STATE SERVICE VERSION" << RESET << endl;
    regex pattern(R"((\d+/tcp)\s+(open)\s+(\S+)\s+([\S\s]+))");
    smatch matches;
    auto search_start = nmap_output.cbegin();
    bool found = false;
    while (regex_search(search_start, nmap_output.cend(), matches, pattern)) {
        cout << GREEN << matches[1] << " " << matches[2] << " " << matches[3] << " " << matches[4] << RESET << endl;
        search_start = matches.suffix().first;
        found = true;
    }
    if (!found) cout << GREEN << "No open ports found." << RESET << endl;
}

// Run command and save output, then print it
void runCommandSaveAndPrint(const string& command, const string& outputPath) {
    FILE* pipe = popen(command.c_str(), "r");
    if (!pipe) {
        cerr << YELLOW << "[!] Failed to run command." << RESET << endl;
        return;
    }
    ofstream outFile(outputPath);
    char buffer[128];
    while (fgets(buffer, sizeof(buffer), pipe)) {
        string line(buffer);
        if (line.find("[") != string::npos || line.find("---") != string::npos || line.find("===") != string::npos) {
            cout << BOLD << GREEN << line << RESET;
        } else {
            cout << CYAN << line << RESET;
        }
        outFile << line;
    }
    fclose(pipe);
    outFile.close();
}

// libcurl callback
size_t WriteCallback(void* contents, size_t size, size_t nmemb, string* output) {
    size_t totalSize = size * nmemb;
    output->append((char*)contents, totalSize);
    return totalSize;
}

// Get HTML content
string getHTML(const string& url) {
    CURL* curl = curl_easy_init();
    string response;
    if (curl) {
        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
        curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
        curl_easy_setopt(curl, CURLOPT_USERAGENT, "Mozilla/5.0");
        curl_easy_perform(curl);
        curl_easy_cleanup(curl);
    }
    return response;
}

// Normalize relative URLs
string normalizeURL(const string& baseUrl, const string& foundUrl) {
    if (foundUrl.find("http") == 0 || foundUrl.find("//") == 0) return foundUrl;
    return baseUrl + foundUrl;
}

// Extract all endpoints
vector<string> extractEndpoints(const string& html, const string& baseUrl) {
    set<string> uniqueEndpoints;
    regex pattern(R"((href|src|action)=["'](.*?)["'])");
    smatch match;
    auto searchStart = html.cbegin();
    while (regex_search(searchStart, html.cend(), match, pattern)) {
        string url = normalizeURL(baseUrl, match[2]);
        uniqueEndpoints.insert(url);
        searchStart = match.suffix().first;
    }
    return vector<string>(uniqueEndpoints.begin(), uniqueEndpoints.end());
}

// Extract JS files
vector<string> extractJSFiles(const string& html, const string& baseUrl) {
    set<string> jsFiles;
    regex pattern(R"(src=["'](.*?\.js(\?.*?)?)["'])");
    smatch match;
    auto searchStart = html.cbegin();
    while (regex_search(searchStart, html.cend(), match, pattern)) {
        string jsFile = normalizeURL(baseUrl, match[1]);
        jsFiles.insert(jsFile);
        searchStart = match.suffix().first;
    }
    return vector<string>(jsFiles.begin(), jsFiles.end());
}

// Run endpoint logic
void runEndpointLogic(const string& url, const string& outputPath) {
    string html = getHTML(url);
    if (html.empty()) {
        cerr << YELLOW << "[!] Failed to fetch website content." << RESET << endl;
        return;
    }
    vector<string> endpoints = extractEndpoints(html, url);
    vector<string> jsFiles = extractJSFiles(html, url);
    ofstream outFile(outputPath);
    cout << GREEN << "\n[+] Unique Endpoints Found:" << RESET << endl;
    outFile << "[+] Unique Endpoints Found:\n";
    for (const string& endpoint : endpoints) {
        cout << CYAN << endpoint << RESET << endl;
        outFile << endpoint << endl;
    }
    cout << GREEN << "\n[+] JavaScript Files Found:" << RESET << endl;
    outFile << "\n[+] JavaScript Files Found:\n";
    for (const string& js : jsFiles) {
        cout << CYAN << js << RESET << endl;
        outFile << js << endl;
    }
    outFile.close();
}

// Run scan_vuln.py
void runScanVuln(const string& url) {
    string command = "python3 scan_vuln.py pull --host " + url;
    cout << GREEN << "\n[+] Running Vulnerability Scanner..." << RESET << endl;
    runCommandSaveAndPrint(command, "result/" + extractDomain(url) + "/scan_vuln.txt");
}

// Main
int main() {
    string url;
    cout << CYAN << "Enter the target URL (e.g., http://example.com): " << RESET;
    getline(cin, url);

    string domain = extractDomain(url);
    if (domain.empty()) {
        cerr << YELLOW << "[!] Invalid domain." << RESET << endl;
        return 1;
    }
    string resultDir = "result/" + domain;
    createDirectory(resultDir);

    cout << GREEN << "\n[+] Running Nmap on " << domain << "..." << RESET << endl;
    runNmap(domain, resultDir + "/nmap.txt");

    cout << GREEN << "\n[+] Running WhatWeb on " << url << "..." << RESET << endl;
    runCommandSaveAndPrint("whatweb " + url, resultDir + "/whatweb.txt");

    cout << GREEN << "\n[+] Extracting Endpoints from " << url << "..." << RESET << endl;
    runEndpointLogic(url, resultDir + "/endpoint.txt");

    runScanVuln(url);

    cout << GREEN << "\n[✔] All tasks completed." << RESET << endl;
    return 0;
}
