#include <iostream>
#include <fstream>
#include <string>
#include <regex>
#include <cstdlib>
#include <unistd.h>
#include <csignal>

using namespace std;

// Global variable to check whether to skip the current step
bool skipCurrentStep = false;

void signalHandler(int signum) {
    cout << "\n[!] Step skipped.\n";
    skipCurrentStep = true;
}

// Function to run Nmap scan
void runNmap(const string& domain, const string& outputPath) {
    if (skipCurrentStep) return;
    string command = "nmap -sV --open " + domain + " 2>&1";  // Default Nmap scan
    FILE* fp = popen(command.c_str(), "r");
    if (!fp) {
        cerr << "[!] Failed to run nmap command." << endl;
        return;
    }

    char buffer[128];
    string nmap_output;
    while (fgets(buffer, sizeof(buffer), fp)) nmap_output += buffer;
    fclose(fp);

    ofstream outFile(outputPath);
    outFile << nmap_output;
    outFile.close();

    cout << "[+] Nmap Scan Results:\n";
    cout << "PORT   STATE SERVICE VERSION" << endl;
    regex pattern(R"((\d+/tcp)\s+(open)\s+(\S+)\s+([\S\s]+))");
    smatch matches;
    auto search_start = nmap_output.cbegin();
    bool found = false;
    while (regex_search(search_start, nmap_output.cend(), matches, pattern)) {
        cout << matches[1] << " " << matches[2] << " " << matches[3] << " " << matches[4] << endl;
        search_start = matches.suffix().first;
        found = true;
    }
    if (!found) cout << "No open ports found." << endl;
}

// Function to run WhatWeb scan
void runWhatWeb(const string& domain, const string& outputPath) {
    if (skipCurrentStep) return;
    string command = "whatweb " + domain + " 2>&1";  // WhatWeb scan
    FILE* fp = popen(command.c_str(), "r");
    if (!fp) {
        cerr << "[!] Failed to run whatweb command." << endl;
        return;
    }

    char buffer[128];
    string whatweb_output;
    while (fgets(buffer, sizeof(buffer), fp)) whatweb_output += buffer;
    fclose(fp);

    ofstream outFile(outputPath);
    outFile << whatweb_output;
    outFile.close();

    cout << "[+] WhatWeb Scan Results:\n";
    cout << whatweb_output << endl;
}

// Function to run endpoint discovery (using a simple dirbuster or similar)
void runEndpointDiscovery(const string& domain, const string& outputPath) {
    if (skipCurrentStep) return;
    string command = "gospider -s " + domain + " --depth 3 --output " + outputPath + " 2>&1";  // Simple endpoint discovery
    FILE* fp = popen(command.c_str(), "r");
    if (!fp) {
        cerr << "[!] Failed to run gospider command." << endl;
        return;
    }

    char buffer[128];
    string endpoint_output;
    while (fgets(buffer, sizeof(buffer), fp)) endpoint_output += buffer;
    fclose(fp);

    ofstream outFile(outputPath);
    outFile << endpoint_output;
    outFile.close();

    cout << "[+] Endpoint Discovery Results:\n";
    cout << endpoint_output << endl;
}

// Function to find subdomains
void runSubdomainDiscovery(const string& domain, const string& outputPath) {
    if (skipCurrentStep) return;
    string command = "subfinder -d " + domain + " -o " + outputPath + " 2>&1";  // Subdomain discovery
    FILE* fp = popen(command.c_str(), "r");
    if (!fp) {
        cerr << "[!] Failed to run subfinder command." << endl;
        return;
    }

    char buffer[128];
    string subdomain_output;
    while (fgets(buffer, sizeof(buffer), fp)) subdomain_output += buffer;
    fclose(fp);

    ofstream outFile(outputPath);
    outFile << subdomain_output;
    outFile.close();

    cout << "[+] Subdomain Discovery Results:\n";
    cout << subdomain_output << endl;
}

// Main function to run all the tasks
int main() {
    // Set up signal handler for skipping tasks
    signal(SIGINT, signalHandler);

    string domain;
    cout << "Enter the target URL (e.g., http://example.com): ";
    cin >> domain;

    string nmapOutput = "nmap_output.txt";
    string whatwebOutput = "whatweb_output.txt";
    string endpointOutput = "endpoint_output.txt";
    string subdomainOutput = "subdomain_output.txt";

    cout << "[+] Running Nmap scan for " << domain << "...\n";
    runNmap(domain, nmapOutput);

    if (!skipCurrentStep) {
        cout << "[+] Running WhatWeb scan for " << domain << "...\n";
        runWhatWeb(domain, whatwebOutput);
    }

    if (!skipCurrentStep) {
        cout << "[+] Running Endpoint Discovery for " << domain << "...\n";
        runEndpointDiscovery(domain, endpointOutput);
    }

    if (!skipCurrentStep) {
        cout << "[+] Running Subdomain Discovery for " << domain << "...\n";
        runSubdomainDiscovery(domain, subdomainOutput);
    }

    cout << "[✔] All tasks completed.\n";
    return 0;
}

