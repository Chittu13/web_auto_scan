#!/bin/bash

echo "Compiling scanner.cpp..."
g++ auto.cpp -o auto -lcurl

if [ $? -eq 0 ]; then
    echo "Compilation successful!"
    echo "Starting scan..."
    ./auto
else
    echo "Compilation failed."
fi

