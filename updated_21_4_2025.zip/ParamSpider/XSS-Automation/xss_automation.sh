#!/bin/bash

# Check if domain is passed
if [ -z "$1" ]; then
    echo "Usage: $0 <domain>"
    exit 1
fi

domain=$1
timestamp=$(date +%F_%T | tr ':' '-')
output_dir="recon-$domain-$timestamp"
mkdir -p "$output_dir"

# Helper function to check if a tool exists
check_tool() {
    if ! command -v "$1" &> /dev/null; then
        echo "[!] $1 not found! Please install it before running this script."
        exit 1
    fi
}

# Required tools
tools=(subfinder httpx waybackurls gau gospider hakrawler katana dalfox gf uro)
for tool in "${tools[@]}"; do
    check_tool "$tool"
done

echo "[*] Starting reconnaissance for: $domain"
echo "[*] Output directory: $output_dir"

# Subdomain Enumeration
echo "[*] Running Subfinder..."
subfinder -d "$domain" -silent | sort -u | tee "$output_dir/subdomains.txt"

# Live Hosts Detection
echo "[*] Checking live subdomains with httpx..."
httpx -l "$output_dir/subdomains.txt" -silent -status-code | tee "$output_dir/live.txt"

# Wayback Machine URLs
echo "[*] Collecting URLs from Wayback Machine..."
waybackurls "$domain" | sort -u > "$output_dir/waybackurls.txt"

# GAU (GetAllUrls)
echo "[*] Collecting URLs using gau..."
gau "$domain" | sort -u > "$output_dir/gau.txt"

# Spidering (Gospider, Hakrawler, Katana) - Parallel Execution
echo "[*] Running web spiders in parallel..."

gospider -s "https://$domain" -o "$output_dir/gospider" -t 10 -c 10 -d 1 -q > "$output_dir/gospider.txt" &
hakrawler -url "https://$domain" -depth 2 -plain > "$output_dir/hakrawler.txt" &
katana -u "https://$domain" -o "$output_dir/katana.txt" -d 2 -silent &

wait

# Combine all collected URLs
echo "[*] Combining all URLs..."
cat "$output_dir"/{waybackurls.txt,gau.txt,gospider.txt,hakrawler.txt,katana.txt} | sort -u | tee "$output_dir/all-urls.txt"

# Clean URLs
echo "[*] Cleaning URLs using uro..."
cat "$output_dir/all-urls.txt" | uro | tee "$output_dir/clean-urls.txt"

# GF Pattern Matching
echo "[*] Extracting potential XSS, SSRF, LFI, SQLi patterns..."
declare -A gf_patterns=(
    ["xss"]="xss"
    ["ssrf"]="ssrf"
    ["lfi"]="lfi"
    ["sqli"]="sqli"
)

for key in "${!gf_patterns[@]}"; do
    gf "${gf_patterns[$key]}" < "$output_dir/clean-urls.txt" | sort -u | tee "$output_dir/$key.txt"
done

# Dalfox Scan (optional, add parallel if needed)
echo "[*] Scanning for XSS with Dalfox..."
dalfox file "$output_dir/xss.txt" -o "$output_dir/dalfox-xss.txt"

echo "[✔] Recon completed. Results stored in: $output_dir"

