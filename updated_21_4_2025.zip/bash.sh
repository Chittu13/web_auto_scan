#!/bin/bash

# Check if scanner executable exists
if [[ ! -f "./auto" ]]; then
    echo "auto.cpp not compiled. Compiling now..."
    g++ auto.cpp -o auto -lcurl

fi

# Run the scanner executable
echo "Running scanner..."
./auto
